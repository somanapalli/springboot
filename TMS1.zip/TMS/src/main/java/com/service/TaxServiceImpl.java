package com.service;

import org.springframework.stereotype.Component;

import com.model.UserClaim;

@Component
public class TaxServiceImpl implements TaxService{

	@Override
	public double calculateTax(UserClaim userClaim) {
		double taxClaimAmount;
		double expenseAmt=userClaim.getExpenseAmt();
		String expenseType=userClaim.getExpenseType();
		if(expenseType.equals("MedicalExpense")){
			if(expenseAmt<=1000){
				taxClaimAmount=expenseAmt*(0.15);
			}
			else if(expenseAmt>=1001 && expenseAmt<=10000){
				taxClaimAmount=expenseAmt*(0.2);
			}
			else{
				taxClaimAmount=expenseAmt*(0.25);
			}
		}
		else if(expenseType.equals("TravelExpense")){
			if(expenseAmt<=1000){
				taxClaimAmount=expenseAmt*(0.1);
			}
			else if(expenseAmt>=1001 && expenseAmt<=10000){
				taxClaimAmount=expenseAmt*(0.15);
			}
			else{
				taxClaimAmount=expenseAmt*(0.2);
			}
		}
		else{
			if(expenseAmt<=1000){
				taxClaimAmount=expenseAmt*(0.05);
			}
			else if(expenseAmt>=1001 && expenseAmt<=10000){
				taxClaimAmount=expenseAmt*(0.1);
			}
			else{
				taxClaimAmount=expenseAmt*(0.15);
			}
		}
		return taxClaimAmount;
	}

}
