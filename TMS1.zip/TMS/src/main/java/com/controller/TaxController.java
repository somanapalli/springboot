package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.UserClaim;
import com.service.TaxService;

@Controller
public class TaxController {
	
	@Autowired
	private TaxService taxService;

	@ModelAttribute("expenseList")
	public List<String> populateExpense(){
		List<String> list=new ArrayList<>();
		list.add("MedicalExpense");
		list.add("TravelExpense");
		list.add("FoodExpense");
		return list;
	}
	
	@RequestMapping(value="/getTaxClaimFormPage",method=RequestMethod.GET)
	public String claimPage(@ModelAttribute("userClaim")UserClaim userClaim){
		
		return "taxclaim";
	}
	
	@RequestMapping(value="/calculateTax",method=RequestMethod.POST)
	public String calculateTax(@Valid@ModelAttribute("userClaim")UserClaim userClaim, BindingResult result,ModelMap map) {
		if(result.hasErrors()){
			return "taxclaim";
		}
		map.put("taxClaimAmount", taxService.calculateTax(userClaim));
		return "result";
	}

	
}
